# Sistem Informasi Manajemen Rumah Sakit

Nama Kelompok
* M Fazar Zuhdi       118140005
* Defangga Aby Vonega 118140015
* Mohamad Aditia      118140018

Ditulis dalam Java menggunakan Netbeans dan MySQL
Sistem Informasi Manajemen Rumah Sakit yang saya buat untuk TUBES PBO, saya menggunakan bahasa Java di netbeans dengan kombinasi dari Database MySQL.

* Menggunakan MySQL di backend
* Memberikan perlindungan kata sandi
* Antarmuka yang Ramah
* Rekam dan Retrive data

# Proses Startup
* Pertama, Atur Mysql dengan menggunakan file MyHospital.sql lalu Ekspor ke dalam PHP MY ADMIN
* Lalu tunggulah sampai Proses Ekspor selesai
* Selanjutnya Anda perlu mengunduh dua file jar rs2xml.jar dan My-SQL Connector yang diberikan dalam proyek dan menambahkannya ke lib Anda di proyek netbeans

# Menjalankan Netbeans
* Kemudian buat nama proyek aplikasi java baru 'MyHospital' dan pastikan itu kosong (hapus semua file paket di dalamnya).
* Kemudian salin folder MyHospital dari file yang diberikan dan tempel di C: \ Users \ YOURUSERNAME \ Documents \ NetBeansProjects dan timpa dan selesai.

# Lisensi Di Bawah! 
[AUR] (https://img.shields.io/badge/License-GNU-blue.svg)

Coding Coding Coding Duarr Eror #GHAMATIKA18 :)
# TubesPbo
# Tubes_PBO_ITERA
